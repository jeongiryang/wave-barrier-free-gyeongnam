# Connecting the service introduction page

The standalone preview contains no service introduction page. Keep the real page mounted beneath `WaveIntro` (or mount it in `onExitStart`). Do not wait until completion to mount the destination: the exit should reveal the prepared page through the canvas.

```tsx
const [introVisible, setIntroVisible] = useState(true);
const [pageReady, setPageReady] = useState(false);
return <>
  <ExistingServiceIntroduction inert={!pageReady} />
  {introVisible && <WaveIntro
    onExitStart={() => setPageReady(true)}
    onComplete={() => { setIntroVisible(false); headingRef.current?.focus(); }}
  />}
</>;
```

- 0–700ms: flowing blue waves and a dense 3D droplet cloud, not a reference photo.
- 700–1600ms: those same droplets gather into the SGIS 2020 Gyeongnam silhouette.
- 1600–2400ms: the complete province remains visible for 800ms, closer to the other icons' caption windows; its caption fades in over 180ms: “경상남도에서 시작되는, 모두를 위한 여행”.
- 2400–3500ms: the province dissolves throughout the 3D viewport, then the original icon sequence continues.
- Later scenes shift by 2731ms without changing their pacing: WAVE at 11177ms, caption begins at 11397ms (same 220ms delay).
- 11881–12731ms: WAVE and the Korean caption disperse; the background becomes transparent.
- `onExitStart` fires once at 11881ms, `onComplete` once at 12731ms.
- Escape calls both callbacks once, bypasses the remaining animation, and leaves no invisible pointer-blocking overlay.
- The parent owns focus restoration, scroll locking and the real service page. The preview's global styles are not intended to replace the host service's CSS.
- No main-service deployment, new introduction-page design, or merge is included in this local revision.

Checkpoint PR #667 contains the earlier version only. These changes intentionally remain on `codex/wave-boundary-transition`.
