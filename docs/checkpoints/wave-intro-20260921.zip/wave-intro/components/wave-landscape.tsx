import { useMemo, useRef, useEffect, type MutableRefObject } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

const ridges = [
  [[0,.34],[.08,.43],[.15,.38],[.24,.44],[.32,.37],[.42,.4],[.51,.34],[.61,.38],[.7,.34],[.81,.46],[.9,.42],[1,.4]],
  [[0,.34],[.08,.39],[.19,.43],[.29,.36],[.37,.4],[.5,.32],[.59,.35],[.7,.4],[.8,.45],[.91,.52],[1,.45]],
  [[0,.32],[.08,.4],[.16,.38],[.24,.34],[.34,.39],[.43,.32],[.51,.3],[.6,.33],[.7,.34],[.8,.41],[.91,.48],[1,.39]],
];
const vertex = 'varying vec2 vUv; void main(){vUv=uv; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}';
const fragment = /* glsl */ `
  varying vec2 vUv;
  uniform float uTime;
  uniform float uOpacity;
  float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
  float noise(vec2 p){vec2 i=floor(p), f=fract(p); f=f*f*(3.-2.*f); return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.),f.x),f.y);}
  void main(){
    vec2 uv=vUv;
    float horizon=.30;
    float below=max(0.,horizon-uv.y);
    float perspective=1./(.06+below);
    vec2 p=vec2((uv.x-.5)*perspective*4.,perspective*2.4);
    float water=noise(p+vec2(uTime*.22,uTime*.13));
    float detail=noise(p*3.1+vec2(-uTime*.36,uTime*.12));
    float ripples=pow(max(0.,sin(p.y*2.8+water*6.+uTime*.8)),12.);
    float reflection=exp(-pow((uv.x-.49)/(.008+below*.58),2.));
    vec3 color=vec3(.002,.016,.045)+vec3(.012,.09,.2)*water;
    color+=vec3(.1,.4,.75)*ripples*(.12+reflection*.9)*(.3+detail);
    color+=vec3(.15,.58,1.)*reflection*(.17+water*.35);
    float wave=.315+.24*exp(-pow((uv.x-.19)/.22,2.))-.02*uv.x;
    float d=abs(uv.y-wave-sin(uv.x*28.-uTime*.7)*.002);
    vec3 glow=vec3(.13,.47,1.)*exp(-d*70.)*.7+vec3(.7,.91,1.)*exp(-d*650.);
    float center=exp(-length((uv-vec2(.49,.302))*vec2(13.,65.)));
    glow+=vec3(.4,.72,1.)*center*3.;
    float mask=1.-smoothstep(horizon-.003,horizon+.003,uv.y);
    color=mix(vec3(0.),color,mask)+glow;
    gl_FragColor=vec4(color,uOpacity*max(mask,clamp(length(glow),0.,1.)));
  }
`;

export function WaveLandscape({ timelineRef }: {timelineRef:MutableRefObject<number>}) {
  const viewport=useThree(s=>s.viewport);
  const group=useRef<THREE.Group>(null);
  const geometries=useMemo(()=>ridges.map(points=>{
    const shape=new THREE.Shape(); shape.moveTo(-.5,-.5);
    points.forEach(([x,y])=>shape.lineTo(x-.5,y-.5));
    shape.lineTo(.5,-.5); shape.closePath(); return new THREE.ShapeGeometry(shape);
  }),[]);
  const materials=useMemo(()=>['#12437b','#09264d','#02132d'].map(color=>new THREE.MeshBasicMaterial({color,transparent:true,opacity:0,depthWrite:false})),[]);
  const water=useMemo(()=>new THREE.ShaderMaterial({vertexShader:vertex,fragmentShader:fragment,transparent:true,depthWrite:false,uniforms:{uTime:{value:0},uOpacity:{value:0}}}),[]);
  useFrame(()=>{
    const t=THREE.MathUtils.clamp((timelineRef.current-8846)/1154,0,1);
    const alpha=t*t*(3-2*t);
    if(group.current) group.current.visible=alpha>0;
    materials.forEach(m=>m.opacity=alpha);
    water.uniforms.uOpacity.value=alpha;
    water.uniforms.uTime.value=timelineRef.current/1000;
  });
  useEffect(()=>()=>{geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());water.dispose();},[geometries,materials,water]);
  return <group ref={group} position={[0,0,-.9]} scale={[viewport.width*1.18,viewport.height*1.18,1]}>
    {geometries.map((g,i)=><mesh key={i} geometry={g} material={materials[i]} position={[0,0,i*.001]} />)}
    <mesh material={water} position={[0,0,.004]}><planeGeometry args={[1,1]}/></mesh>
  </group>;
}
