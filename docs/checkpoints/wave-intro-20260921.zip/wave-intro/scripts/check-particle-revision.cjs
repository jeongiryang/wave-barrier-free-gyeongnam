const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const sharp = require('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
const { chromium } = require('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

(async () => {
  const out = path.resolve('artifacts/particle-revision');
  fs.mkdirSync(out, { recursive: true });
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
  const errors = [];
  page.on('pageerror', error => errors.push(String(error)));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  await page.addInitScript(() => {
    window.particleAudit = { count: 0, frames: [] };
    const draw = WebGL2RenderingContext.prototype.drawArrays;
    WebGL2RenderingContext.prototype.drawArrays = function(mode, first, count) {
      if (mode === this.POINTS) {
        window.particleAudit.count = count;
        window.particleAudit.frames.push(performance.now());
      }
      return draw.call(this, mode, first, count);
    };
  });
  const scenes = [];
  for (const time of (process.env.STABILITY_ONLY ? [] : [0, 1538, 2308, 3050, 3846, 4500, 5385, 6154, 6923, 8550, 8750, 10000])) {
    await page.goto(`http://localhost:5173/?introTime=${time}`);
    await page.waitForFunction(t => Number(document.querySelector('.wave-intro')?.dataset.timeMs) === t, time);
    await page.waitForTimeout(500);
    const scene = await page.evaluate(() => ({
      time: Number(document.querySelector('.wave-intro').dataset.timeMs),
      count: window.particleAudit.count,
      captions: [...document.querySelectorAll('[data-icon-caption]')].filter(e => Number(getComputedStyle(e).opacity) > .01).map(e => e.textContent),
      subtitle: Number(getComputedStyle(document.querySelector('.wave-intro__subtitle')).opacity),
      removedFinal: document.querySelectorAll('.wave-intro__final').length === 0,
    }));
    scenes.push(scene);
    assert.equal(scene.count, 330000);
    assert.equal(scene.removedFinal, true);
    await page.screenshot({ path: path.join(out, `${time}.png`) });
  }
  if (!process.env.STABILITY_ONLY) {
  assert.deepEqual(scenes.find(s => s.time === 2308).captions, ['누구나 자유롭게,']);
  assert.deepEqual(scenes.find(s => s.time === 3846).captions, ['언제든 편안하게,']);
  assert.deepEqual(scenes.find(s => s.time === 5385).captions, ['더 멀리, 더 함께,']);
  assert.deepEqual(scenes.find(s => s.time === 6923).captions, ['모든 순간, 함께하는 여행.']);
  assert.equal(scenes.find(s => s.time === 8550).subtitle, 0);
  assert.ok(scenes.find(s => s.time === 8750).subtitle > 0);
  assert.equal(scenes.find(s => s.time === 10000).subtitle, 1);
  }
  await page.goto('http://localhost:5173/?introTime=10000');
  await page.waitForFunction(() => document.querySelector('.wave-intro')?.dataset.timeMs === '10000' && window.particleAudit.count === 330000);
  await page.waitForTimeout(700);
  const before = await sharp(await page.locator('canvas').screenshot({path:path.join(out,'stable-before.png')})).raw().toBuffer();
  await page.waitForTimeout(300);
  const after = await sharp(await page.locator('canvas').screenshot({path:path.join(out,'stable-after.png')})).raw().toBuffer();
  let differentChannels = 0, largestDifference = 0;
  for (let i=0; i<before.length; i++) {
    const delta = Math.abs(before[i]-after[i]);
    if(delta) differentChannels++;
    largestDifference = Math.max(largestDifference, delta);
  }
  const stability = {differentChannels, largestDifference, totalChannels:before.length};
  console.log(JSON.stringify({stability}));
  // Permit isolated one-level GPU rounding, not motion or global brightness drift.
  assert.ok(largestDifference <= 1 && differentChannels / before.length < 0.0001, 'Final particle WAVE must remain still');
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('http://localhost:5173/?introTime=5385');
  await page.waitForFunction(() => document.querySelector('.wave-intro')?.dataset.timeMs === '5385' && window.particleAudit.count === 144000);
  await page.waitForTimeout(900);
  const mobile = await page.evaluate(() => ({ count: window.particleAudit.count, width: innerWidth, scrollWidth: document.documentElement.scrollWidth }));
  assert.equal(mobile.count, 144000);
  assert.equal(mobile.width, mobile.scrollWidth);
  await page.screenshot({ path: path.join(out, 'mobile-mother-child.png') });
  assert.deepEqual(errors, []);
  fs.writeFileSync(path.join(out, 'checks.json'), JSON.stringify({ scenes, mobile, stability, errors }, null, 2));
  console.log(JSON.stringify({ scenes, mobile, stability, errors }));
  await browser.close();
})().catch(error => { console.error(error); process.exit(1); });
