const fs=require('node:fs');
const path=require('node:path');
const runtime='C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/';
const {chromium}=require(runtime+'playwright');
const sharp=require(runtime+'sharp');
const times=[0,769,1538,2308,3077,3846,4615,5385,6154,6923,7692,8846,10000];
const rects=[[26,113,396,204],[436,113,392,204],[843,113,392,204],[1252,113,396,204],[26,376,391,204],[432,376,396,204],[844,376,391,204],[1253,376,395,204],[26,639,294,189],[336,639,298,189],[648,639,311,189],[975,639,309,189],[1300,639,348,221]];
const out=path.resolve('artifacts/storyboard-review');
(async()=>{
 fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({channel:'msedge',headless:true,args:['--enable-webgl','--ignore-gpu-blocklist']});
 const page=await browser.newPage({viewport:{width:1280,height:720},deviceScaleFactor:1});
 const errors=[];const requests=[];
 page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 page.on('request',r=>requests.push(r.url()));
 const results=[];
 for(let i=0;i<times.length;i++){
   await page.goto('http://localhost:5173/?introTime='+times[i]);
   await page.waitForFunction(t=>Number(document.querySelector('.wave-intro')?.dataset.timeMs)===t,times[i]);
   await page.waitForTimeout(500);
   const shot=await page.screenshot({path:path.join(out,`${i.toString().padStart(2,'0')}.png`)});
   const [left,top,width,height]=rects[i];
   const ref=await sharp('C:/Users/admin/AppData/Local/Temp/codex-clipboard-817c7b7d-9efd-4214-b7e0-4d9f375e1245.png').extract({left,top,width,height}).resize(640,360,{fit:'contain',background:'#010917'}).png().toBuffer();
   const actual=await sharp(shot).resize(640,360).png().toBuffer();
   results.push({i,time:times[i],ref:ref.toString('base64'),actual:actual.toString('base64')});
 }
 const states=[];
 for(const t of [8550,8750,8846]){
  await page.goto('http://localhost:5173/?introTime='+t);await page.waitForTimeout(650);
  states.push(await page.evaluate(()=>({time:document.querySelector('.wave-intro').dataset.timeMs,opacity:getComputedStyle(document.querySelector('.wave-intro__subtitle')).opacity,brandLayers:document.querySelectorAll('.wave-intro__brand').length})));
 }
 await page.goto('http://localhost:5173/');await page.waitForTimeout(900);await page.keyboard.press('Escape');await page.waitForTimeout(600);
 const escape=await page.locator('.wave-intro').getAttribute('data-time-ms');
 await page.setViewportSize({width:390,height:844});await page.goto('http://localhost:5173/?introTime=6923');await page.waitForTimeout(600);await page.screenshot({path:path.join(out,'mobile.png')});
 const report={errors,states,escape,forbiddenRequests:requests.filter(r=>/\/scenes\/|clipboard|\.mp4/.test(r))};
 fs.writeFileSync(path.join(out,'checks.json'),JSON.stringify(report,null,2));
 fs.writeFileSync(path.join(out,'index.html'),`<!doctype html><meta charset="utf-8"><title>WAVE 13장면 비교</title><style>body{background:#031023;color:#def;font:16px sans-serif;margin:30px}section{margin:24px 0} .pair{display:flex}img{width:50%}h2{font-size:18px}p{line-height:1.6}</style><h1>스토리보드 / 실시간 구현</h1><p>왼쪽: 첨부 보드 프레임. 오른쪽: 해당 시점 WebGL 렌더. 원본 번호는 비교용 원본에만 존재합니다.</p>${results.map(r=>`<section><h2>${String(r.i).padStart(2,'0')} · ${r.time} ms</h2><div class="pair"><img src="data:image/png;base64,${r.ref}"><img src="data:image/png;base64,${r.actual}"></div></section>`).join('')}`);
 console.log(JSON.stringify(report));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
