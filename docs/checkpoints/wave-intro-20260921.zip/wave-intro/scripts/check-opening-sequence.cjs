const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {chromium}=require('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const {toSceneTime,toPlaybackTime,INTRO_DURATION_MS,BOUNDARY_FORMED_MS,BOUNDARY_HOLD_END_MS,OPENING_DURATION_MS}=require('../components/wave-timing.ts');
(async()=>{
 const out=path.resolve('artifacts/opening-sequence');fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1280,height:720}});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 const states=[];
 for(const time of [0,350,700,1150,1600,1900,2200,BOUNDARY_HOLD_END_MS,BOUNDARY_HOLD_END_MS+550,OPENING_DURATION_MS,toPlaybackTime(2308)]){
  await page.goto('http://localhost:5173/?introTime='+time);
  await page.waitForFunction(t=>Number(document.querySelector('.wave-intro')?.dataset.timeMs)===t,time);
  await page.waitForTimeout(350);
  states.push(await page.locator('[data-boundary-caption]').evaluate((e,time)=>({time,opacity:+getComputedStyle(e).opacity,text:e.textContent.trim()}),time));
  await page.screenshot({path:path.join(out,time+'.png')});
 }
 for(const t of [0,700,1150,1600,BOUNDARY_HOLD_END_MS+550,OPENING_DURATION_MS])assert.equal(states.find(s=>s.time===t).opacity,0);
 for(const t of [1900,2200,BOUNDARY_HOLD_END_MS])assert.equal(states.find(s=>s.time===t).opacity,1);
 assert.equal(states.find(s=>s.time===1900).text,'경상남도에서 시작되는, 모두를 위한 여행');
 for(const scene of [769,2308,8446,8666,9150,10000])assert.ok(Math.abs(toSceneTime(toPlaybackTime(scene))-scene)<1e-6);
 assert.equal(BOUNDARY_HOLD_END_MS-BOUNDARY_FORMED_MS,800);
 assert.equal(OPENING_DURATION_MS-BOUNDARY_HOLD_END_MS,1100);
 assert.equal(INTRO_DURATION_MS,12731);
 await page.setViewportSize({width:390,height:844});
 await page.goto('http://localhost:5173/?introTime=1900');
 await page.waitForFunction(()=>document.querySelector('.wave-intro')?.dataset.timeMs==='1900');
 await page.waitForTimeout(350);
 const mobile=await page.locator('[data-boundary-caption]').evaluate(e=>{const r=e.getBoundingClientRect();return {left:r.left,right:r.right,bottom:r.bottom,width:innerWidth,height:innerHeight,opacity:+getComputedStyle(e).opacity}});
 assert.ok(mobile.left>=0 && mobile.right<=mobile.width && mobile.bottom<=mobile.height && mobile.opacity===1);
 await page.screenshot({path:path.join(out,'mobile-map-caption.png')});
 assert.deepEqual(errors,[]);
 fs.writeFileSync(path.join(out,'checks.json'),JSON.stringify({states,mobile,errors},null,2));
 console.log(JSON.stringify({states,mobile,errors}));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
