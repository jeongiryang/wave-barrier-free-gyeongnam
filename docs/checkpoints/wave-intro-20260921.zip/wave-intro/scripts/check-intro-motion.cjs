const {INTRO_DURATION_MS,toPlaybackTime}=require('../components/wave-timing.ts');
const fs=require('node:fs');
const {chromium}=require('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const context=await browser.newContext({viewport:{width:1280,height:720}});
 const page=await context.newPage();
 await page.addInitScript(()=>{
   window.introAudit={start:null,end:null,count:0,frames:[]};
   let previous=false;
   new MutationObserver(()=>{
    const e=document.querySelector('.wave-intro'); if(!e)return;
    const t=Number(e.dataset.timeMs);const done=e.dataset.complete==='true';
    if(t>0 && window.introAudit.start===null)window.introAudit.start=performance.now()-t;
    if(done&&!previous){window.introAudit.count++;window.introAudit.end=performance.now();}
    previous=done;
   }).observe(document,{subtree:true,attributes:true,attributeFilter:['data-time-ms','data-complete']});
 });
 await page.goto('http://localhost:5173/');
 await page.waitForFunction(()=>document.querySelector('.wave-intro')?.dataset.complete==='true',{},{timeout:20000});
 const timing=await page.evaluate(()=>({duration:window.introAudit.end-window.introAudit.start,completionTransitions:window.introAudit.count}));
 await page.goto('http://localhost:5173/');await page.waitForTimeout(700);await page.keyboard.press('Escape');await page.waitForTimeout(1200);
 const escape=await page.evaluate(()=>({time:document.querySelector('.wave-intro').dataset.timeMs,complete:document.querySelector('.wave-intro').dataset.complete,count:window.introAudit.count}));
 await page.emulateMedia({reducedMotion:'reduce'});await page.goto('http://localhost:5173/?introTime='+toPlaybackTime(8750));await page.waitForTimeout(600);
 const reduced=await page.locator('.wave-intro__subtitle').evaluate(e=>({opacity:getComputedStyle(e).opacity,transform:getComputedStyle(e).transform,filter:getComputedStyle(e).filter}));
 const result={timing,escape,reduced};fs.writeFileSync('artifacts/storyboard-review/motion-checks.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
 await browser.close();
 if(Math.abs(timing.duration-INTRO_DURATION_MS)>50||timing.completionTransitions!==1||escape.time!==String(INTRO_DURATION_MS)||reduced.transform!=='none')process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
