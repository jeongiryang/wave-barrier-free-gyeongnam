from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageOps


SOURCE = Path(sys.argv[1])
OUTPUT = Path(sys.argv[2])
TARGET = (1600, 900)

# Only the image inside each storyboard frame is used. Everything surrounding
# these rectangles is production reference material, not part of the intro.
PANELS = [
    ("00-wave", (20, 137, 472, 373)),
    ("01-burst", (487, 137, 934, 373)),
    ("02-wheelchair-form", (949, 137, 1397, 373)),
    ("03-wheelchair", (1412, 137, 1866, 373)),
    ("04-solo-form", (20, 435, 469, 669)),
    ("05-solo", (482, 435, 934, 669)),
    ("06-family-form", (948, 435, 1397, 669)),
    ("07-family", (1412, 435, 1865, 669)),
    ("08-family-expand", (20, 734, 359, 952)),
    ("09-family-solid", (371, 734, 713, 952)),
    ("10-word-form", (726, 734, 1083, 952)),
    ("11-word", (1097, 734, 1451, 952)),
    ("12-landscape", (1463, 734, 1866, 989)),
]


def feathered_patch(panel: Image.Image, box: tuple[int, int, int, int], source_box: tuple[int, int, int, int]) -> None:
    width = box[2] - box[0]
    height = box[3] - box[1]
    patch = panel.crop(source_box).resize((width, height), Image.Resampling.LANCZOS)
    patch = ImageEnhance.Brightness(patch).enhance(0.86).filter(ImageFilter.GaussianBlur(2.2))
    mask = Image.new("L", (width, height), 255)
    mask_pixels = mask.load()
    feather = max(4, min(14, width // 12, height // 5))
    for py in range(height):
        for px in range(width):
            distance = min(px, py, width - 1 - px, height - 1 - py)
            mask_pixels[px, py] = int(255 * min(1.0, distance / feather))
    panel.paste(patch, box[:2], mask)


def remove_label(panel: Image.Image, width: int, height: int) -> None:
    sample = panel.crop((width, 0, panel.width, height)).resize((1, 1), Image.Resampling.BOX)
    average = sample.getpixel((0, 0))
    color = tuple(max(1, int(channel * 0.46)) for channel in average)
    patch = Image.new("RGB", (width, height), color)
    mask = Image.new("L", (width, height), 255)
    mask_pixels = mask.load()
    feather = 12
    for py in range(height):
        for px in range(width):
            # Top and left touch the cropped scene boundary; only feather the
            # inner-facing right and bottom edges so no label pixels survive.
            distance = min(width - 1 - px, height - 1 - py)
            mask_pixels[px, py] = int(255 * min(1.0, distance / feather))
    panel.paste(patch, (0, 0), mask)


def clean_panel(name: str, image: Image.Image, crop: tuple[int, int, int, int]) -> Image.Image:
    # Trim the cyan storyboard frame itself.
    panel = image.crop((crop[0] + 3, crop[1] + 3, crop[2] - 3, crop[3] - 3)).convert("RGB")
    width, height = panel.size

    # Replace the top-left scene number/time label using neighboring dark sky.
    label_w = min(width // 3, 145)
    label_h = min(height // 4, 52)
    remove_label(panel, label_w, label_h)

    # A blurred cover fills widescreen edges while the undistorted panel remains
    # centered. This is especially important for the narrower bottom-row panels.
    background = ImageOps.fit(panel, TARGET, method=Image.Resampling.LANCZOS)
    background = background.filter(ImageFilter.GaussianBlur(24))
    background = ImageEnhance.Brightness(background).enhance(0.43)
    background = ImageEnhance.Color(background).enhance(1.18)

    foreground = ImageOps.contain(panel, TARGET, method=Image.Resampling.LANCZOS)
    foreground = ImageEnhance.Color(foreground).enhance(1.15)
    foreground = ImageEnhance.Contrast(foreground).enhance(1.08)
    foreground = foreground.filter(ImageFilter.UnsharpMask(radius=1.6, percent=115, threshold=3))
    x = (TARGET[0] - foreground.width) // 2
    y = (TARGET[1] - foreground.height) // 2

    alpha = Image.new("L", foreground.size, 255)
    edge = max(20, min(90, foreground.width // 12))
    draw = ImageDraw.Draw(alpha)
    for step in range(edge):
        value = int(255 * (step / edge) ** 0.65)
        draw.line((step, 0, step, foreground.height), fill=value)
        draw.line((foreground.width - 1 - step, 0, foreground.width - 1 - step, foreground.height), fill=value)
    alpha = alpha.filter(ImageFilter.GaussianBlur(4))
    background.paste(foreground, (x, y), alpha)

    # Reinforce the reference's midnight-blue grade and hide upscaling artifacts.
    blue_tint = Image.new("RGB", TARGET, (0, 30, 78))
    output = ImageChops.screen(background, ImageEnhance.Brightness(blue_tint).enhance(0.22))
    output = output.filter(ImageFilter.UnsharpMask(radius=1.2, percent=70, threshold=4))
    return output


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    source = Image.open(SOURCE)
    for name, crop in PANELS:
        scene = clean_panel(name, source, crop)
        scene.save(OUTPUT / f"{name}.webp", "WEBP", quality=92, method=6)


if __name__ == "__main__":
    main()
