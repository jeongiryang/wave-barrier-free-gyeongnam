const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const {chromium}=require('C:/Users/admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

const {toPlaybackTime,toSceneTime}=require('../components/wave-timing.ts');
const at = t => Math.round(toPlaybackTime(t));

(async()=>{
 const out=path.resolve('artifacts/boundary-transition'); fs.mkdirSync(out,{recursive:true});
 const browser=await chromium.launch({channel:'msedge',headless:true});
 const page=await browser.newPage({viewport:{width:1280,height:720}});
 const errors=[]; page.on('pageerror',e=>errors.push(String(e)));
 page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 const installUnderlay=()=>{
  const box=document.createElement('section'); box.id='service-fixture';
  box.setAttribute('aria-label','서비스 소개 페이지 연결 테스트');
  box.style.cssText='position:fixed;inset:0;background:linear-gradient(120deg,#092b43,#164966);color:white;display:grid;place-content:center;text-align:center;font:24px sans-serif;z-index:0';
  box.innerHTML='<h1>소개 페이지 연결 테스트</h1><p>실제 서비스 화면이 아닌 투명 전환 검증용 배경</p><button id="service-test-button">클릭 확인</button>';
  document.querySelector('.intro-page').append(box);
  box.querySelector('button').onclick=()=>box.dataset.clicked='true';
 };
 const states=[];
 for(const t of [0,150,400,769,2308,5385,8446,8846,9149,9190,9500,9800,10000]){
  await page.goto('http://localhost:5173/?introTime='+at(t));
  await page.waitForFunction(t=>Number(document.querySelector('.wave-intro')?.dataset.timeMs)===t,at(t));
  if(t>=9149) await page.evaluate(installUnderlay);
  await page.waitForTimeout(500);
  await page.screenshot({path:path.join(out,`${t}.png`)});
  states.push(await page.locator('.wave-intro').evaluate(e=>({playbackTime:+e.dataset.timeMs,time:+e.dataset.timeMs,exiting:e.dataset.exiting,complete:e.dataset.complete,visibility:getComputedStyle(e).visibility,subtitle:+getComputedStyle(e.querySelector('.wave-intro__subtitle')).opacity})));
 }
 states.forEach(s => { s.time = Math.round(toSceneTime(s.time)); });
 assert.equal(states.find(s=>s.time===9149).exiting,'false');
 assert.equal(states.find(s=>s.time===9190).exiting,'true');
 assert.equal(states.find(s=>s.time===9149).subtitle,1);
 assert.equal(states.find(s=>s.time===9190).subtitle,0);
 assert.equal(states.find(s=>s.time===10000).visibility,'hidden');
 await page.locator('#service-test-button').click();
 assert.equal(await page.locator('#service-fixture').getAttribute('data-clicked'),'true');
 await page.goto('http://localhost:5173/');
 await page.waitForFunction(()=>Number(document.querySelector('.wave-intro')?.dataset.timeMs)>0);
 await page.evaluate(installUnderlay);
 await page.keyboard.press('Escape'); await page.waitForTimeout(500);
 assert.equal(await page.locator('.wave-intro').getAttribute('data-complete'),'true');
 await page.locator('#service-test-button').click();
 assert.equal(await page.locator('#service-fixture').getAttribute('data-clicked'),'true');
 await page.setViewportSize({width:390,height:844});
 for(const t of [0,9200,10000]){
  await page.goto('http://localhost:5173/?introTime='+at(t));
  await page.waitForFunction(t=>Number(document.querySelector('.wave-intro')?.dataset.timeMs)===t,at(t));
  if(t>=9200)await page.evaluate(installUnderlay);
  await page.waitForTimeout(500);
  await page.screenshot({path:path.join(out,`mobile-${t}.png`)});
 }
 assert.deepEqual(errors,[]);
 fs.writeFileSync(path.join(out,'checks.json'),JSON.stringify({states,errors,escape:'pass',underlayClick:'pass'},null,2));
 console.log(JSON.stringify({states,errors,escape:'pass',underlayClick:'pass'}));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
