import { WaveIntro } from "@/components/wave-intro";

export default function Home() {
  return (
    <main className="intro-page">
      <WaveIntro />
    </main>
  );
}
